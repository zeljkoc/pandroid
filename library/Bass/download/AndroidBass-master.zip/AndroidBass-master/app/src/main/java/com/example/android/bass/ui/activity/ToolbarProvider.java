package com.example.android.bass.ui.activity;

import android.support.v7.widget.Toolbar;

public interface ToolbarProvider {

    Toolbar getToolbar();

}