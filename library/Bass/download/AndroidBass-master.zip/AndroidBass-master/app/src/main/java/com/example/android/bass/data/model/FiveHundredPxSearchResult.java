package com.example.android.bass.data.model;

import java.util.List;

public class FiveHundredPxSearchResult {

    private List<FiveHundredPxPhoto> photos;

    public List<FiveHundredPxPhoto> getPhotos() {
        return photos;
    }
}
