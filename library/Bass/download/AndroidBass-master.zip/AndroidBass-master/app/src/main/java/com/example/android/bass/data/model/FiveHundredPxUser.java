package com.example.android.bass.data.model;

public class FiveHundredPxUser {

    private String fullname;

    public String getFullname() {
        return fullname;
    }
}
