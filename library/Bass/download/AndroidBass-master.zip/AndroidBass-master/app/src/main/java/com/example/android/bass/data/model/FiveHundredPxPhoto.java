package com.example.android.bass.data.model;

public class FiveHundredPxPhoto {

    private int id;
    private String image_url;
    private String name;
    private FiveHundredPxUser user;

    public int getId() {
        return id;
    }

    public String getImageUrl() {
        return image_url;
    }

    public String getName() {
        return name;
    }

    public FiveHundredPxUser getUser() {
        return user;
    }
}
